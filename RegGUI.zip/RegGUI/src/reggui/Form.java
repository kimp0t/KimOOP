/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package reggui;


/**
 *
 * @author imbol
 */
///registrationform class  
public class Form {
    protected String Firstname, Lastname,FamilyID;
    public String Dob;
    public String Gender, Address;

    public Form() {
    }

    public Form(String Firstname, String Lastname, String FamilyID, String Dob, String Gender, String Address) {
        this.Firstname = Firstname;
        this.Lastname = Lastname;
        this.FamilyID = FamilyID;
        this.Dob = Dob;
        this.Gender = Gender;
        this.Address = Address;
    }

    public String getFirstname() {
        return Firstname;
    }

    public void setFirstname(String Firstname) {
        this.Firstname = Firstname;
    }

    public String getLastname() {
        return Lastname;
    }

    public void setLastname(String Lastname) {
        this.Lastname = Lastname;
    }

    public String getFamilyID() {
        return FamilyID;
    }

    public void setFamilyID(String FamilyID) {
        this.FamilyID = FamilyID;
    }

    public String getDob() {
        return Dob;
    }

    public void setDob(String Dob) {
        this.Dob = Dob;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String Gender) {
        this.Gender = Gender;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String Address) {
        this.Address = Address;
    }

    @Override
    public String toString() {
        return "Form{" + "Firstname=" + Firstname + ", Lastname=" + Lastname + ", FamilyID=" + FamilyID + ", Dob=" + Dob + ", Gender=" + Gender + ", Address=" + Address + '}';
    }
    
    
    
}
